package org.example;

import lombok.Data;

@Data
public class Customer {
    int id;
    String name;
    String email;
}
